package main
/**
 * @author Rancho
 * @date ${DATE}
 */

func main() {
	#[[$END$]]#
}
