package ${GO_PACKAGE_NAME}
/**
 * @author Rancho
 * @date ${DATE}
 */