#!/usr/bin/env python
# encoding: utf-8
$Import

setup(
    name='$Package_name',
    version='$Version',
    packages=$PackageList,$PackageDirs
    url='$URL',
    license='$License',
    author='$Author',
    author_email='$Author_Email',
    description='$Description'
)
